
Survival Fairness (Experimental)
================================


Calculate Survival fairness (Experimental)

Parameters
----------
    CoxPh_kwargs : _type_, optional
        _description_, by default None
    confounds : _type_, optional
        _description_, by default None

