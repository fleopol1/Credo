.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   credoai

automodule: credoai_lens