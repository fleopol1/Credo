"""Containers for different input data types"""
