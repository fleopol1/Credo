"""
Direct connection to the package credoai-connect.

The credoai_connect package handles all protocols linking a local Lens run
to CredoAI Platform.
"""
from connect.governance import Governance
