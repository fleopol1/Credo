CREDO_URL = "https://api.credo.ai"
# used to determine when certain multiclass functionality should be executed
# e.g., label balance in dataset fairness
MULTICLASS_THRESH = 6
